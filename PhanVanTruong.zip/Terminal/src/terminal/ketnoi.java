/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package terminal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author DELL
 */
public  class ketnoi {

    private static Connection conn;
    private static PreparedStatement stmt;

    public void KetNoiCSDL() {
        try {
            String dbURL = "jdbc:sqlserver://localhost\\SQLEXPRESS;databaseName=SinhVien;user=sa;password=1234";
            conn = DriverManager.getConnection(dbURL);
            if (conn != null) {
                System.out.println("Ket noi thanh cong!");

            }
        } catch (SQLException ex) {
            System.out.println("Loi ket noi " + ex);
        }
    }

    public ResultSet TruyVan(String sql) // truy van tra ve kieu string
    {
        ResultSet rs = null;
        try {
            KetNoiCSDL();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
        } catch (Exception ex) {
            System.out.println(" loi : " + ex);
        }
        return rs;
    }

    public void CapNhat(String sql) {
        try {
            KetNoiCSDL();
            stmt = conn.prepareStatement(sql);
            int row = stmt.executeUpdate();
            if (row == 1) {
                System.out.println("Thanh Cong");
            }
            stmt.close();
            conn.close();

        } catch (Exception ex) {
            System.out.println("loi " + ex);
        }
    }
  
}
